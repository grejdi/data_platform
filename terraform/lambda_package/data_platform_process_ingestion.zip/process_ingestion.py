def run(event, context):
  return {}
