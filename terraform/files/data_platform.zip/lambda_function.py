def lambda_handler(event, context):
  return {}
